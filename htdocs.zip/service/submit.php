<?php
    include "fetcher.php";

    $db = new MySqlDatabase();

    $type = $_POST["type"];

    switch ($type) {
        case "insert":
            $country = $_POST["country"];
            $country = $db->quote(convertCountryNameToCode($country)[0]["CountryCode"]);

            $series = $_POST["series"];
            $series = $db->quote(convertSeriesNameToCode($series)[0]["SeriesCode"]);

            $year = $_POST["year"];
            $year = $db->quote($year . " [YR" . $year . "]");

            $data = $_POST["data"];

            $sql = "INSERT INTO databyyear (CountryCode, SeriesCode, YearC, Data) VALUES (" . $country . ", " . $series . ", "  . $year . ", "  . $data . ")";

            // $db->query($sql);
            // echo $db->error();
            break;

        case "update":
            $id = $_POST["id"];
            
            $country = $db->quote(convertCountryNameToCode($country)[0]["CountryCode"]);

            $series = $_POST["series"];
            $series = $db->quote(convertSeriesNameToCode($series)[0]["SeriesCode"]);

            $year = $_POST["year"];
            $year = $db->quote($year . " [YR" . $year . "]");

            $data = $_POST["data"];

            // $sql = "INSERT INTO databyyear (CountryCode, SeriesCode, YearC, Data) VALUES (" . $country . ", " . $series . ", "  . $year . ", "  . $data . ")";
            $sql = "UPDATE databyyear SET CountryCode = " .  $country . ", SeriesCode = " .  $series . ", YearC = " .  $year . ", Data = "  . $data . " WHERE Id = " . $id;
            echo $sql;

            // $db->query($sql);
            // echo $db->error();
            break;

        case "delete":
            $data = json_decode($_POST["data"], true);

            $sql = "DELETE FROM wdi2.databyyear WHERE Id = ?";

            $connection = $db->connect();
            $connection->autocommit(FALSE);

            $connection->begin_transaction();

            $statement = $connection->prepare($sql);
            if ($statement == false) {
                echo $sql;
            }

            foreach($data as $id) {
                $statement->bind_param("i", $id);

                if (!$statement->execute())
                {
                    $connection->rollback();
                    exit();
                }
            }
            
            $statement->close();
            $connection->commit();
            $connection->close();

            break;
    }

    header("Location: ../index.php");
    exit();
?>